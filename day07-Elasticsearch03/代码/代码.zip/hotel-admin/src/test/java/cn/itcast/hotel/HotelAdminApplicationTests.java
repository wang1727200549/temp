package cn.itcast.hotel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelAdminApplicationTests {

    @Test
    void contextLoads() {
    }

}
